package eu.onlynelchilling.venrixutils;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.concurrent.CompletableFuture;

public final class TeleportUtils {
    private TeleportUtils() {
    }

    public static CompletableFuture<Boolean> teleportAsync(Player player, Location location) {
        return player.teleportAsync(location);
    }

    public static void teleport(Player player, Location location) {
        player.teleport(location);
    }
}

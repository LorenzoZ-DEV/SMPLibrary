package eu.onlynelchilling.venrixutils;

import co.aikar.commands.PaperCommandManager;
import eu.onlynelchilling.venrixutils.admin.VenrixUtilsCommand;
import eu.onlynelchilling.venrixutils.combat.CombatManager;
import eu.onlynelchilling.venrixutils.info.DiscordCommand;
import eu.onlynelchilling.venrixutils.info.StoreCommand;
import eu.onlynelchilling.venrixutils.info.VoteCommand;
import eu.onlynelchilling.venrixutils.message.MessageService;
import eu.onlynelchilling.venrixutils.nightvision.NightVisionCommand;
import eu.onlynelchilling.venrixutils.spawn.SpawnCommand;
import eu.onlynelchilling.venrixutils.spawn.SpawnQueueManager;
import eu.onlynelchilling.venrixutils.streak.StreakManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class VenrixUtils extends JavaPlugin {

    private SpawnQueueManager spawnQueueManager;
    private MessageService messageService;
    private CombatManager combatManager;
    private StreakManager streakManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.messageService = new MessageService(this);

        this.spawnQueueManager = new SpawnQueueManager(this, messageService);
        this.spawnQueueManager.load();

        this.combatManager = new CombatManager(this, messageService);
        this.combatManager.start();

        this.streakManager = new StreakManager(this, messageService);
        this.streakManager.start();

        PaperCommandManager commandManager = new PaperCommandManager(this);
        commandManager.enableUnstableAPI("brigadier");
        commandManager.registerCommand(new SpawnCommand(this, spawnQueueManager, messageService));
        commandManager.registerCommand(new NightVisionCommand(this, messageService));
        commandManager.registerCommand(new DiscordCommand(messageService));
        commandManager.registerCommand(new VoteCommand(messageService));
        commandManager.registerCommand(new StoreCommand(messageService));
        commandManager.registerCommand(new VenrixUtilsCommand(this, messageService));
    }

    @Override
    public void onDisable() {
        if (streakManager != null) streakManager.stop();
        if (combatManager != null) combatManager.stop();
        if (spawnQueueManager != null) {
            spawnQueueManager.stop();
            spawnQueueManager.flushBlocking();
        }
    }

    public void reloadAll() {
        reloadConfig();
        if (messageService != null) messageService.reload();
        if (spawnQueueManager != null) spawnQueueManager.reload();
        if (combatManager != null) combatManager.reload();
        if (streakManager != null) streakManager.reload();
    }

    public SpawnQueueManager getSpawnQueueManager() { return spawnQueueManager; }
    public MessageService getMessageService() { return messageService; }
    public CombatManager getCombatManager() { return combatManager; }
    public StreakManager getStreakManager() { return streakManager; }
}

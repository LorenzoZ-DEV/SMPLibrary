package eu.onlynelchilling.venrixutils.nightvision;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.Optional;
import eu.onlynelchilling.venrixutils.VenrixUtils;
import eu.onlynelchilling.venrixutils.message.MessageService;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class NightVisionCommand extends BaseCommand implements Listener {

    private final VenrixUtils plugin;
    private final MessageService messages;
    private final Set<UUID> nightVisionPlayers = new HashSet<>();

    public NightVisionCommand(VenrixUtils plugin, MessageService messages) {
        this.plugin = plugin;
        this.messages = messages;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @CommandAlias("nightvision|nv")
    public void onNightvision(Player player, @Optional Player target) {
        Player resolvedTarget = target == null ? player : target;

        if (resolvedTarget.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
            resolvedTarget.removePotionEffect(PotionEffectType.NIGHT_VISION);
            nightVisionPlayers.remove(resolvedTarget.getUniqueId());
            String messageKey = player != resolvedTarget
                    ? "Night-Vision.nightvision-disabled-other"
                    : "Night-Vision.nightvision-disabled";
            player.sendMessage(messages.get(messageKey, Placeholder.unparsed("target", resolvedTarget.getName())));
        } else {
            resolvedTarget.addPotionEffect(new PotionEffect(
                    PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false, false));
            nightVisionPlayers.add(resolvedTarget.getUniqueId());
            String messageKey = player != resolvedTarget
                    ? "Night-Vision.nightvision-enabled-other"
                    : "Night-Vision.nightvision-enabled";
            player.sendMessage(messages.get(messageKey, Placeholder.unparsed("target", resolvedTarget.getName())));
        }
    }

    @EventHandler
    public void onPlayerConsumeMilk(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        if (event.getItem().getType() == Material.MILK_BUCKET) {
            if (nightVisionPlayers.contains(player.getUniqueId())) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> player.addPotionEffect(
                        new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false, false)), 1L);
            }
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (nightVisionPlayers.contains(player.getUniqueId())) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> player.addPotionEffect(
                    new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false, false)), 1L);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        nightVisionPlayers.remove(event.getPlayer().getUniqueId());
    }
}

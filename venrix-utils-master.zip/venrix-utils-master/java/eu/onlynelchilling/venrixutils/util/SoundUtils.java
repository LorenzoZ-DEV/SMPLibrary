package eu.onlynelchilling.venrixutils.util;

import org.bukkit.Sound;

import java.util.Locale;

public final class SoundUtils {

    private SoundUtils() {}

    public static Sound resolve(String name, Sound fallback) {
        if (name == null || name.isBlank()) return fallback;
        try {
            return Sound.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }
}

package eu.onlynelchilling.venrixutils.util;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;

public final class CounterTask {

    private final int reach;
    private final BooleanSupplier shouldStop;
    private final Runnable onStop;
    private final IntConsumer onRepeat;
    private final Runnable onComplete;

    private BukkitTask task;
    private int counter = 0;

    private CounterTask(Builder b) {
        this.reach = b.reach;
        this.shouldStop = b.shouldStop;
        this.onStop = b.onStop;
        this.onRepeat = b.onRepeat;
        this.onComplete = b.onComplete;
    }

    public static Builder builder() {
        return new Builder();
    }

    public void start(JavaPlugin plugin, boolean async) {
        Runnable tick = () -> {
            if (shouldStop != null && shouldStop.getAsBoolean()) {
                cancel();
                if (onStop != null) onStop.run();
                return;
            }
            if (counter >= reach) {
                cancel();
                if (onComplete != null) onComplete.run();
                return;
            }
            if (onRepeat != null) onRepeat.accept(counter);
            counter++;
        };
        BukkitScheduler scheduler = plugin.getServer().getScheduler();
        this.task = async
                ? scheduler.runTaskTimerAsynchronously(plugin, tick, 0L, 20L)
                : scheduler.runTaskTimer(plugin, tick, 0L, 20L);
    }

    public void cancel() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    public static final class Builder {
        private int reach;
        private BooleanSupplier shouldStop;
        private Runnable onStop;
        private IntConsumer onRepeat;
        private Runnable onComplete;

        public Builder reach(int reach) { this.reach = reach; return this; }
        public Builder shouldStop(BooleanSupplier s) { this.shouldStop = s; return this; }
        public Builder onStop(Runnable r) { this.onStop = r; return this; }
        public Builder onRepeat(IntConsumer r) { this.onRepeat = r; return this; }
        public Builder onComplete(Runnable r) { this.onComplete = r; return this; }
        public CounterTask build() { return new CounterTask(this); }
    }
}

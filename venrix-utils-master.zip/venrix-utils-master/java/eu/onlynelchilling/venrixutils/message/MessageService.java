package eu.onlynelchilling.venrixutils.message;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessageService {

    private static final String MESSAGES_FILE = "messages.yml";
    private static final String LEGACY_FORMAT_CODES = "0123456789abcdefklmnorx";
    private static final Pattern HEX_PATTERN = Pattern.compile("&#([0-9a-fA-F]{6})");

    private final JavaPlugin plugin;
    private final File file;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final LegacyComponentSerializer legacySerializer =
            LegacyComponentSerializer.builder().character('&').hexCharacter('x').hexColors().build();
    private final Map<String, String> raw = new HashMap<>();
    private final Map<String, List<String>> rawLists = new HashMap<>();
    private final Cache<String, Component> cache;

    private Component prefix = Component.empty();

    public MessageService(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), MESSAGES_FILE);
        this.cache = Caffeine.newBuilder()
                .maximumSize(256)
                .expireAfterAccess(Duration.ofMinutes(30))
                .build();
        reload();
    }

    public void reload() {
        if (!file.exists()) {
            plugin.saveResource(MESSAGES_FILE, false);
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        raw.clear();
        rawLists.clear();
        cache.invalidateAll();

        for (String key : cfg.getKeys(true)) {
            if (cfg.isString(key)) {
                raw.put(key, cfg.getString(key));
            } else if (cfg.isList(key)) {
                rawLists.put(key, cfg.getStringList(key));
            }
        }
        prefix = parse(raw.getOrDefault("prefix", ""), false);
    }

    public boolean has(String key) {
        return raw.containsKey(key) || rawLists.containsKey(key);
    }

    public Component get(String key) {
        return cache.get(key, k -> parse(rawOf(k), true));
    }

    public Component get(String key, TagResolver... resolvers) {
        String r = applyHex(rawOf(key));
        if (isLegacy(r)) {
            return withDefaults(legacySerializer.deserialize(r));
        }
        TagResolver[] all = new TagResolver[resolvers.length + 1];
        all[0] = prefixResolver();
        System.arraycopy(resolvers, 0, all, 1, resolvers.length);
        return withDefaults(miniMessage.deserialize(r, all));
    }

    public List<Component> getList(String key) {
        List<String> raws = rawLists.getOrDefault(key, Collections.emptyList());
        List<Component> result = new ArrayList<>(raws.size());
        for (String r : raws) result.add(parse(r, true));
        return result;
    }

    public void sendList(CommandSender sender, String key) {
        for (Component line : getList(key)) sender.sendMessage(line);
    }

    public void broadcast(Component component) {
        plugin.getServer().broadcast(component);
    }

    private Component parse(String raw, boolean withPrefix) {
        if (raw == null || raw.isEmpty()) return Component.empty();
        String input = applyHex(raw);
        Component component = isLegacy(input)
                ? legacySerializer.deserialize(input)
                : (withPrefix
                        ? miniMessage.deserialize(input, prefixResolver())
                        : miniMessage.deserialize(input));
        return withDefaults(component);
    }

    private boolean isLegacy(String s) {
        for (int i = 0; i + 1 < s.length(); i++) {
            if (s.charAt(i) == '&'
                    && LEGACY_FORMAT_CODES.indexOf(Character.toLowerCase(s.charAt(i + 1))) >= 0) {
                return true;
            }
        }
        return false;
    }

    private String applyHex(String s) {
        if (s == null || s.indexOf('&') < 0) return s;
        Matcher matcher = HEX_PATTERN.matcher(s);
        if (!matcher.find()) return s;
        StringBuilder out = new StringBuilder(s.length() + 16);
        do {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("&x");
            for (int i = 0; i < 6; i++) {
                replacement.append('&').append(hex.charAt(i));
            }
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement.toString()));
        } while (matcher.find());
        matcher.appendTail(out);
        return out.toString();
    }

    private Component withDefaults(Component component) {
        return component
                .decorationIfAbsent(TextDecoration.BOLD, TextDecoration.State.FALSE)
                .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    private String rawOf(String key) {
        String s = raw.get(key);
        return s != null ? s : "<red>missing message: " + key;
    }

    private TagResolver prefixResolver() {
        return Placeholder.component("prefix", prefix);
    }
}

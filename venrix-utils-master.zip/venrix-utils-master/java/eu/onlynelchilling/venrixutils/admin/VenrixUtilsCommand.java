package eu.onlynelchilling.venrixutils.admin;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.CommandPermission;
import co.aikar.commands.annotation.Default;
import co.aikar.commands.annotation.Subcommand;
import eu.onlynelchilling.venrixutils.VenrixUtils;
import eu.onlynelchilling.venrixutils.message.MessageService;
import org.bukkit.command.CommandSender;

import java.util.logging.Level;

@CommandAlias("venrixutils|vutils")
public class VenrixUtilsCommand extends BaseCommand {

    private final VenrixUtils plugin;
    private final MessageService messages;

    public VenrixUtilsCommand(VenrixUtils plugin, MessageService messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    @Default
    @Subcommand("reload")
    @CommandPermission("venrixutils.admin")
    public void onReload(CommandSender sender) {
        try {
            plugin.reloadAll();
            sender.sendMessage(messages.get("Admin.reload-success"));
        } catch (Exception ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to reload VenrixUtils", ex);
            sender.sendMessage(messages.get("Admin.reload-failed"));
        }
    }
}

package eu.onlynelchilling.venrixutils.info;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.Description;
import eu.onlynelchilling.venrixutils.message.MessageService;
import org.bukkit.command.CommandSender;

public class VoteCommand extends BaseCommand {

    private final MessageService messages;

    public VoteCommand(MessageService messages) {
        this.messages = messages;
    }

    @CommandAlias("vote")
    public void onVote(CommandSender sender) {
        messages.sendList(sender, "Vote");
    }
}

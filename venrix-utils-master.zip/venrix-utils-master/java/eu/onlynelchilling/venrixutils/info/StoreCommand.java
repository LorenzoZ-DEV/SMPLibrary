package eu.onlynelchilling.venrixutils.info;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.CommandAlias;
import eu.onlynelchilling.venrixutils.message.MessageService;
import org.bukkit.command.CommandSender;

public class StoreCommand extends BaseCommand {

    private final MessageService messages;

    public StoreCommand(MessageService messages) {
        this.messages = messages;
    }

    @CommandAlias("store|buy")
    public void onStore(CommandSender sender) {
        messages.sendList(sender, "Store");
    }
}

package eu.onlynelchilling.venrixutils.info;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.Description;
import eu.onlynelchilling.venrixutils.message.MessageService;
import org.bukkit.command.CommandSender;

public class DiscordCommand extends BaseCommand {

    private final MessageService messages;

    public DiscordCommand(MessageService messages) {
        this.messages = messages;
    }

    @CommandAlias("discord")
    public void onDiscord(CommandSender sender) {
        messages.sendList(sender, "Discord");
    }
}

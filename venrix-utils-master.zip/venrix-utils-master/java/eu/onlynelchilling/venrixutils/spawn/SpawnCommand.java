package eu.onlynelchilling.venrixutils.spawn;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.CommandPermission;
import co.aikar.commands.annotation.Description;
import eu.onlynelchilling.venrixutils.message.MessageService;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class SpawnCommand extends BaseCommand {

    private final JavaPlugin plugin;
    private final SpawnQueueManager queueManager;
    private final MessageService messages;

    public SpawnCommand(JavaPlugin plugin, SpawnQueueManager queueManager, MessageService messages) {
        this.plugin = plugin;
        this.queueManager = queueManager;
        this.messages = messages;
    }

    @CommandAlias("spawn")
    public void onSpawn(Player player) {
        int delay = player.hasPermission(SpawnQueueManager.BYPASS_PERMISSION)
                ? 0
                : Math.max(0, plugin.getConfig().getInt("Spawn.delay"));
        queueManager.teleportToSpawn(player, delay);
    }

    @CommandAlias("setspawn")
    @CommandPermission("venrixutils.setspawn")
    public void onSetSpawn(Player player) {
        Location location = player.getLocation().clone();
        queueManager.setSpawn(location).thenRun(() ->
                player.sendMessage(messages.get("Spawn.set"))
        ).exceptionally(ex -> {
            player.sendMessage(messages.get("Spawn.set-failed"));
            return null;
        });
    }
}

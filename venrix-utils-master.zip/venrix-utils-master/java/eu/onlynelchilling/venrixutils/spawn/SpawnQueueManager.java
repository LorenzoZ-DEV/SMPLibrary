package eu.onlynelchilling.venrixutils.spawn;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import eu.onlynelchilling.venrixutils.TeleportUtils;
import eu.onlynelchilling.venrixutils.message.MessageService;
import eu.onlynelchilling.venrixutils.util.CounterTask;
import eu.onlynelchilling.venrixutils.util.SoundUtils;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

public class SpawnQueueManager implements Listener {

    private static final String KEY = "spawn";
    public static final String BYPASS_PERMISSION = "venrixutils.spawn.bypass";

    private final JavaPlugin plugin;
    private final MessageService messages;
    private final File file;
    private final Cache<String, Location> spawnCache;
    private final Map<UUID, CounterTask> activeTeleports = new ConcurrentHashMap<>();

    private volatile Location spawn;

    private boolean cancelOnMove;
    private double maxMoveSq;

    private boolean teleportSoundEnabled;
    private Sound teleportSound;
    private float teleportVolume;
    private float teleportPitch;
    private boolean countdownSoundEnabled;
    private Sound countdownSound;
    private float countdownVolume;
    private float countdownPitch;
    private boolean cancelSoundEnabled;
    private Sound cancelSound;
    private float cancelVolume;
    private float cancelPitch;

    public SpawnQueueManager(JavaPlugin plugin, MessageService messages) {
        this.plugin = plugin;
        this.messages = messages;
        this.file = new File(plugin.getDataFolder(), "spawn.yml");
        this.spawnCache = Caffeine.newBuilder()
                .expireAfterAccess(Duration.ofMinutes(10))
                .maximumSize(8)
                .build();
        loadConfig();
    }

    public void load() {
        CompletableFuture.supplyAsync(this::readFromDisk).thenAccept(loaded -> {
            this.spawn = loaded;
            if (loaded != null) {
                spawnCache.put(KEY, loaded);
            }
        }).exceptionally(ex -> {
            plugin.getLogger().log(Level.SEVERE, "Failed to load spawn", ex);
            return null;
        });
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.hasPlayedBefore()) return;
        Location target = getSpawn();
        if (target == null) return;
        Bukkit.getScheduler().runTask(plugin, () -> teleportNow(player, target));
    }

    public Location getSpawn() {
        Location cached = spawnCache.getIfPresent(KEY);
        if (cached != null) return cached.clone();
        return spawn == null ? null : spawn.clone();
    }

    public CompletableFuture<Void> setSpawn(Location location) {
        Location snapshot = location.clone();
        this.spawn = snapshot;
        this.spawnCache.put(KEY, snapshot);
        return CompletableFuture.runAsync(() -> writeToDisk(snapshot))
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE, "Failed to save spawn", ex);
                    return null;
                });
    }

    public void flushBlocking() {
        if (spawn != null) {
            try {
                writeToDisk(spawn);
            } catch (Exception ex) {
                plugin.getLogger().log(Level.SEVERE, "Failed to flush spawn on disable", ex);
            }
        }
    }

    public void reload() {
        loadConfig();
    }

    private void loadConfig() {
        FileConfiguration cfg = plugin.getConfig();
        this.cancelOnMove = cfg.getBoolean("Spawn.cancel-on-move");
        double maxMove = Math.max(0.0, cfg.getDouble("Spawn.max-move-distance"));
        this.maxMoveSq = maxMove * maxMove;

        this.teleportSoundEnabled = cfg.getBoolean("Spawn.sounds.teleport.enabled");
        this.teleportSound = SoundUtils.resolve(cfg.getString("Spawn.sounds.teleport.type"), Sound.ENTITY_ENDERMAN_TELEPORT);
        this.teleportVolume = (float) cfg.getDouble("Spawn.sounds.teleport.volume");
        this.teleportPitch = (float) cfg.getDouble("Spawn.sounds.teleport.pitch");
        this.countdownSoundEnabled = cfg.getBoolean("Spawn.sounds.countdown-tick.enabled");
        this.countdownSound = SoundUtils.resolve(cfg.getString("Spawn.sounds.countdown-tick.type"), Sound.BLOCK_NOTE_BLOCK_PLING);
        this.countdownVolume = (float) cfg.getDouble("Spawn.sounds.countdown-tick.volume");
        this.countdownPitch = (float) cfg.getDouble("Spawn.sounds.countdown-tick.pitch");
        this.cancelSoundEnabled = cfg.getBoolean("Spawn.sounds.teleport-canceled.enabled");
        this.cancelSound = SoundUtils.resolve(cfg.getString("Spawn.sounds.teleport-canceled.type"), Sound.ENTITY_VILLAGER_NO);
        this.cancelVolume = (float) cfg.getDouble("Spawn.sounds.teleport-canceled.volume");
        this.cancelPitch = (float) cfg.getDouble("Spawn.sounds.teleport-canceled.pitch");
    }

    public void clear() {
        activeTeleports.values().forEach(CounterTask::cancel);
        activeTeleports.clear();
    }

    public void stop() {
        clear();
    }

    public void teleportToSpawn(Player player, int delay) {
        Location target = getSpawn();
        if (target == null) {
            player.sendMessage(messages.get("Spawn.not-set"));
            return;
        }
        teleportWithDelay(player, target, delay);
    }

    public void teleportWithDelay(Player player, Location spawnLocation, int delay) {
        UUID playerId = player.getUniqueId();
        if (activeTeleports.containsKey(playerId)) {
            player.sendMessage(messages.get("Spawn.already-teleporting"));
            return;
        }
        if (delay <= 0) {
            teleportNow(player, spawnLocation);
            return;
        }

        Location startLocation = player.getLocation().clone();
        final int total = delay;
        CounterTask task = CounterTask.builder()
                .reach(delay)
                .shouldStop(() -> !player.isOnline() || hasMoved(player, startLocation))
                .onStop(() -> handleCancellation(player, playerId))
                .onRepeat(i -> {
                    int remaining = total - i;
                    player.sendActionBar(messages.get("Spawn.delay-actionbar",
                            Placeholder.unparsed("time", String.valueOf(remaining))));
                    if (countdownSoundEnabled) {
                        player.playSound(player.getLocation(), countdownSound, countdownVolume, countdownPitch);
                    }
                })
                .onComplete(() -> {
                    activeTeleports.remove(playerId);
                    teleportNow(player, spawnLocation);
                })
                .build();
        activeTeleports.put(playerId, task);
        task.start(plugin, false);
    }

    private void handleCancellation(Player player, UUID playerId) {
        activeTeleports.remove(playerId);
        if (player.isOnline()) {
            player.sendMessage(messages.get("Spawn.teleport-canceled"));
            if (cancelSoundEnabled) {
                player.playSound(player.getLocation(), cancelSound, cancelVolume, cancelPitch);
            }
        }
    }

    private boolean hasMoved(Player player, Location startLocation) {
        if (!cancelOnMove) return false;
        if (player.hasPermission(BYPASS_PERMISSION)) return false;
        Location current = player.getLocation();
        if (current.getWorld() == null || !current.getWorld().equals(startLocation.getWorld())) return true;
        double dx = current.getX() - startLocation.getX();
        double dy = current.getY() - startLocation.getY();
        double dz = current.getZ() - startLocation.getZ();
        return dx * dx + dy * dy + dz * dz > maxMoveSq;
    }

    private void teleportNow(Player player, Location spawnLocation) {
        Location target = centerOnBlock(spawnLocation);
        TeleportUtils.teleportAsync(player, target).thenAccept(success -> {
            if (!Boolean.TRUE.equals(success)) return;
            player.setFallDistance(0.0F);
            if (teleportSoundEnabled) {
                player.playSound(player.getLocation(), teleportSound, teleportVolume, teleportPitch);
            }
            player.sendMessage(messages.get("Spawn.teleported"));
        });
    }

    private Location centerOnBlock(Location location) {
        Location centered = location.clone();
        centered.setX(centered.getBlockX() + 0.5);
        centered.setZ(centered.getBlockZ() + 0.5);
        return centered;
    }

    private Location readFromDisk() {
        if (!file.exists()) return null;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        if (!cfg.contains(KEY + ".world")) return null;

        String worldName = cfg.getString(KEY + ".world");
        UUID worldId = null;
        String rawUuid = cfg.getString(KEY + ".world-uuid");
        if (rawUuid != null) {
            try { worldId = UUID.fromString(rawUuid); } catch (IllegalArgumentException ignored) {}
        }

        final UUID finalWorldId = worldId;
        final String finalWorldName = worldName;

        CompletableFuture<World> worldFuture = new CompletableFuture<>();
        Bukkit.getScheduler().runTask(plugin, () -> {
            World world = finalWorldId != null ? Bukkit.getWorld(finalWorldId) : null;
            if (world == null && finalWorldName != null) world = Bukkit.getWorld(finalWorldName);
            worldFuture.complete(world);
        });

        World world = worldFuture.join();
        if (world == null) {
            plugin.getLogger().warning("Spawn world not loaded: " + worldName);
            return null;
        }

        return new Location(
                world,
                cfg.getDouble(KEY + ".x"),
                cfg.getDouble(KEY + ".y"),
                cfg.getDouble(KEY + ".z"),
                (float) cfg.getDouble(KEY + ".yaw"),
                (float) cfg.getDouble(KEY + ".pitch")
        );
    }

    private void writeToDisk(Location location) {
        if (!file.getParentFile().exists() && !file.getParentFile().mkdirs()) {
            plugin.getLogger().warning("Could not create data folder for spawn.yml");
        }
        YamlConfiguration cfg = new YamlConfiguration();
        World world = location.getWorld();
        cfg.set(KEY + ".world", world != null ? world.getName() : null);
        cfg.set(KEY + ".world-uuid", world != null ? world.getUID().toString() : null);
        cfg.set(KEY + ".x", location.getX());
        cfg.set(KEY + ".y", location.getY());
        cfg.set(KEY + ".z", location.getZ());
        cfg.set(KEY + ".yaw", location.getYaw());
        cfg.set(KEY + ".pitch", location.getPitch());
        try {
            cfg.save(file);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save spawn.yml", e);
        }
    }
}

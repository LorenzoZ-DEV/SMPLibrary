package eu.onlynelchilling.venrixutils.combat;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import eu.onlynelchilling.venrixutils.message.MessageService;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.util.List;
import java.util.UUID;

public class CombatListener implements Listener {

    private final JavaPlugin plugin;
    private final CombatManager combatManager;
    private final MessageService messages;

    private Cache<UUID, UUID> crystalBreaker;
    private Cache<UUID, UUID> lastHitter;
    private Cache<Location, UUID> anchorInteraction;

    private boolean playerAttackTrigger = true;
    private boolean crystalTrigger = true;
    private boolean anchorTrigger = true;

    public CombatListener(JavaPlugin plugin, CombatManager combatManager, MessageService messages) {
        this.plugin = plugin;
        this.combatManager = combatManager;
        this.messages = messages;
        reload();
    }

    public void reload() {
        this.playerAttackTrigger = plugin.getConfig().getBoolean("Combat.triggers.player-attack", true);
        this.crystalTrigger = plugin.getConfig().getBoolean("Combat.triggers.crystal", true);
        this.anchorTrigger = plugin.getConfig().getBoolean("Combat.triggers.respawn-anchor", true);

        long crystalSec = Math.max(1, plugin.getConfig().getLong("Combat.cache.crystal-breaker-seconds", 60));
        long lastHitterSec = Math.max(1, plugin.getConfig().getLong("Combat.cache.last-hitter-seconds", 15));
        long anchorSec = Math.max(1, plugin.getConfig().getLong("Combat.cache.anchor-interaction-seconds", 60));

        this.crystalBreaker = Caffeine.newBuilder()
                .expireAfterWrite(Duration.ofSeconds(crystalSec)).maximumSize(10_000).build();
        this.lastHitter = Caffeine.newBuilder()
                .expireAfterWrite(Duration.ofSeconds(lastHitterSec)).maximumSize(50_000).build();
        this.anchorInteraction = Caffeine.newBuilder()
                .expireAfterWrite(Duration.ofSeconds(anchorSec)).maximumSize(20_000).build();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCrystalBreak(EntityDamageByEntityEvent event) {
        if (!crystalTrigger) return;
        if (event.getEntity() instanceof EnderCrystal crystal
                && event.getDamager() instanceof Player player) {
            crystalBreaker.put(crystal.getUniqueId(), player.getUniqueId());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAnchorInteract(PlayerInteractEvent event) {
        if (!anchorTrigger) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.RESPAWN_ANCHOR) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() == Material.GLOWSTONE) return;
        Location loc = event.getClickedBlock().getLocation();
        anchorInteraction.put(loc, player.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onAnchorExplosionDamage(EntityDamageEvent event) {
        if (!anchorTrigger) return;
        if (!(event.getEntity() instanceof Player player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) return;
        Location damageLocation = event.getDamageSource().getDamageLocation();
        if (damageLocation == null || damageLocation.getWorld() == null) return;
        Location blockLoc = new Location(damageLocation.getWorld(),
                damageLocation.getBlockX(), damageLocation.getBlockY(), damageLocation.getBlockZ());
        UUID interactorUUID = anchorInteraction.getIfPresent(blockLoc);
        anchorInteraction.invalidate(blockLoc);
        if (interactorUUID == null) return;
        Player interactor = Bukkit.getPlayer(interactorUUID);
        if (interactor == null) return;
        if (interactor.equals(player)) {
            combatManager.enterCombat(player);
        } else {
            lastHitter.put(player.getUniqueId(), interactorUUID);
            combatManager.enterCombat(player, interactor);
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        Entity damager = event.getDamager();
        if (damager instanceof Projectile projectile) {
            if (!(projectile.getShooter() instanceof Entity shooter)) return;
            damager = shooter;
        }
        if (damager instanceof EnderCrystal crystal) {
            if (!crystalTrigger) return;
            UUID attackerID = crystalBreaker.getIfPresent(crystal.getUniqueId());
            if (attackerID == null) return;
            Player attacker = Bukkit.getPlayer(attackerID);
            if (attacker == null) return;
            if (attacker.equals(player)) {
                combatManager.enterCombat(player);
            } else {
                lastHitter.put(player.getUniqueId(), attackerID);
                combatManager.enterCombat(player, attacker);
            }
        } else if (damager instanceof Player attacker) {
            if (!playerAttackTrigger) return;
            if (player.equals(attacker)) return;
            lastHitter.put(player.getUniqueId(), attacker.getUniqueId());
            combatManager.enterCombat(player, attacker);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Player killer = player.getKiller();
        if (combatManager.isInCombat(player)) {
            combatManager.removeCombat(player);
        }
        event.deathMessage(pickDeathMessage(player, killer));
    }

    private Component pickDeathMessage(Player player, Player killer) {
        if (killer != null) {
            return messages.get("Death.player",
                    Placeholder.unparsed("player", player.getName()),
                    Placeholder.unparsed("killer", killer.getName()));
        }
        String causeKey = causeKeyOf(player);
        String key = messages.has("Death." + causeKey) ? "Death." + causeKey : "Death.default";
        return messages.get(key, Placeholder.unparsed("player", player.getName()));
    }

    private String causeKeyOf(Player player) {
        EntityDamageEvent last = player.getLastDamageCause();
        if (last == null) return "default";
        return switch (last.getCause()) {
            case FALL -> "fall";
            case DROWNING -> "drowning";
            case VOID -> "void";
            case FIRE, FIRE_TICK, LAVA -> "fire";
            case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK, PROJECTILE -> "mob";
            case BLOCK_EXPLOSION, ENTITY_EXPLOSION -> "explosion";
            case SUFFOCATION -> "suffocation";
            case STARVATION -> "starvation";
            default -> "default";
        };
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (!combatManager.isInCombat(player)) return;
        UUID id = lastHitter.getIfPresent(player.getUniqueId());
        if (id != null) {
            Player killer = Bukkit.getPlayer(id);
            if (killer != null) {
                player.setKiller(killer);
            }
        }
        player.setHealth(0.0);
        combatManager.removeCombat(player);
    }

    @EventHandler
    public void onPreCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!combatManager.isInCombat(player)) return;
        if (player.hasPermission(CombatManager.BYPASS_PERMISSION)) return;
        String command = event.getMessage().split(" ")[0].toLowerCase();
        List<String> allowedCommands = combatManager.allowedCommands();
        if (allowedCommands.contains(command)) return;
        player.sendMessage(messages.get("Combat.cant-execute-command"));
        event.setCancelled(true);
    }
}

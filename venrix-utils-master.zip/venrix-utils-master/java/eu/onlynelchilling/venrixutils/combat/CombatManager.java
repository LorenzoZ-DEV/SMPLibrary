package eu.onlynelchilling.venrixutils.combat;

import eu.onlynelchilling.venrixutils.message.MessageService;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class CombatManager implements Listener {

    public static final String BYPASS_PERMISSION = "venrixutils.combat.bypass";
    private static final String COMBAT_SAVED_KEY = "combat-saved-players";

    private final JavaPlugin plugin;
    private final MessageService messages;
    private final Map<UUID, Integer> combatPlayers = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> lastDamager = new ConcurrentHashMap<>();
    private final Set<UUID> playersToKillOnJoin = ConcurrentHashMap.newKeySet();

    private BukkitTask task;
    private CombatListener combatListener;

    private boolean enabled = true;
    private int cachedCombatTime = 15;
    private boolean killOnQuit = true;
    private boolean killOnRejoin = true;
    private boolean blockEnderChest = true;

    public CombatManager(JavaPlugin plugin, MessageService messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    public void start() {
        loadConfig();
        if (!enabled) return;
        loadSavedCombatPlayers();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        this.combatListener = new CombatListener(plugin, this, messages);
        plugin.getServer().getPluginManager().registerEvents(this.combatListener, plugin);
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this::processCombatPlayers, 0L, 20L);
    }

    public void reload() {
        loadConfig();
        if (combatListener != null) {
            combatListener.reload();
        }
    }

    public void stop() {
        saveCombatPlayersOnShutdown();
        if (task != null) {
            task.cancel();
            task = null;
        }
        combatPlayers.clear();
        lastDamager.clear();
        playersToKillOnJoin.clear();
    }

    private void loadConfig() {
        this.enabled = plugin.getConfig().getBoolean("Combat.enabled", true);
        this.cachedCombatTime = Math.max(0, plugin.getConfig().getInt("Combat.combat-time", 15));
        this.killOnQuit = plugin.getConfig().getBoolean("Combat.kill-on-quit", true);
        this.killOnRejoin = plugin.getConfig().getBoolean("Combat.kill-on-rejoin", true);
        this.blockEnderChest = plugin.getConfig().getBoolean("Combat.block-ender-chest", true);
    }

    private void loadSavedCombatPlayers() {
        List<String> savedUuids = plugin.getConfig().getStringList(COMBAT_SAVED_KEY);
        if (savedUuids.isEmpty()) return;
        for (String s : savedUuids) {
            try { playersToKillOnJoin.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
        }
        plugin.getConfig().set(COMBAT_SAVED_KEY, null);
        plugin.saveConfig();
    }

    private void saveCombatPlayersOnShutdown() {
        if (combatPlayers.isEmpty()) return;
        Set<String> uuidsToSave = combatPlayers.keySet().stream().map(UUID::toString).collect(Collectors.toSet());
        plugin.getConfig().set(COMBAT_SAVED_KEY, uuidsToSave.stream().toList());
        plugin.saveConfig();
    }

    private void processCombatPlayers() {
        if (combatPlayers.isEmpty()) return;
        Iterator<Map.Entry<UUID, Integer>> iterator = combatPlayers.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Integer> entry = iterator.next();
            UUID uuid = entry.getKey();
            int seconds = entry.getValue();
            Player player = Bukkit.getPlayer(uuid);
            if (player == null) {
                iterator.remove();
                lastDamager.remove(uuid);
            } else if (seconds > 0) {
                entry.setValue(seconds - 1);
                player.sendActionBar(messages.get("Combat.action-bar",
                        Placeholder.unparsed("time", String.valueOf(seconds))));
            } else {
                iterator.remove();
                lastDamager.remove(uuid);
                player.sendMessage(messages.get("Combat.exit-combat"));
            }
        }
    }

    public boolean shouldKillOnJoin(UUID uuid) {
        return playersToKillOnJoin.remove(uuid);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (!killOnRejoin) return;
        Player player = event.getPlayer();
        if (shouldKillOnJoin(player.getUniqueId())) {
            player.setHealth(0.0);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        if (!isInCombat(player)) return;
        if (killOnQuit) {
            UUID damagerUUID = lastDamager.get(uuid);
            if (damagerUUID != null) {
                Player damager = Bukkit.getPlayer(damagerUUID);
                if (damager != null && damager.isOnline()) {
                    player.setHealth(0.0);
                    damager.sendMessage(messages.get("Combat.quit-in-combat-killer",
                            Placeholder.unparsed("player", player.getName())));
                }
            }
        }
        combatPlayers.remove(uuid);
        lastDamager.remove(uuid);
    }

    public void enterCombat(Player player, Player damager) {
        if (!enabled) return;
        if (player == null || player.equals(damager)) return;

        boolean playerBypass = player.hasPermission(BYPASS_PERMISSION);
        boolean damagerBypass = damager != null && damager.hasPermission(BYPASS_PERMISSION);

        if (!playerBypass) {
            if (!isInCombat(player)) {
                player.sendMessage(messages.get("Combat.enter-combat"));
            }
            combatPlayers.put(player.getUniqueId(), cachedCombatTime);
        }

        if (damager != null && !damagerBypass) {
            UUID damagerUUID = damager.getUniqueId();
            if (!playerBypass) {
                UUID playerUUID = player.getUniqueId();
                lastDamager.put(playerUUID, damagerUUID);
                lastDamager.put(damagerUUID, playerUUID);
            }
            if (!isInCombat(damager)) {
                damager.sendMessage(messages.get("Combat.enter-combat"));
            }
            combatPlayers.put(damagerUUID, cachedCombatTime);
        }
    }

    public void enterCombat(Player player) {
        if (!enabled) return;
        if (player == null) return;
        if (player.hasPermission(BYPASS_PERMISSION)) return;
        if (!isInCombat(player)) {
            player.sendMessage(messages.get("Combat.enter-combat"));
        }
        combatPlayers.put(player.getUniqueId(), cachedCombatTime);
    }

    public void removeCombat(Player player) {
        UUID uuid = player.getUniqueId();
        if (combatPlayers.remove(uuid) != null) {
            player.sendMessage(messages.get("Combat.exit-combat"));
            lastDamager.remove(uuid);
        }
    }

    public int getTimeLeft(UUID uuid) {
        Integer seconds = combatPlayers.get(uuid);
        return seconds != null ? Math.max(0, seconds) : 0;
    }

    public boolean isInCombat(Player player) {
        Integer seconds = combatPlayers.get(player.getUniqueId());
        return seconds != null && seconds > 0;
    }

    public UUID getLastDamager(UUID uuid) {
        return lastDamager.get(uuid);
    }

    public List<String> allowedCommands() {
        return plugin.getConfig().getStringList("Combat.allowed-commands");
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onEnderChestOpen(PlayerInteractEvent event) {
        if (!blockEnderChest) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.ENDER_CHEST) return;
        Player player = event.getPlayer();
        if (isInCombat(player)) {
            event.setCancelled(true);
            player.sendMessage(messages.get("Combat.cant-execute-command"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!blockEnderChest) return;
        HumanEntity entity = event.getWhoClicked();
        if (!(entity instanceof Player player)) return;
        if (!isInCombat(player)) return;
        if (event.getInventory().getType() == InventoryType.ENDER_CHEST) {
            event.setCancelled(true);
            player.sendMessage(messages.get("Combat.cant-execute-command"));
            player.closeInventory();
        }
    }
}

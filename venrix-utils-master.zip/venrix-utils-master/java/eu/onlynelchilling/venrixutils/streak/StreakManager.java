package eu.onlynelchilling.venrixutils.streak;

import eu.onlynelchilling.venrixutils.message.MessageService;
import eu.onlynelchilling.venrixutils.util.SoundUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class StreakManager implements Listener {

    private static final SoundEntry DISABLED_SOUND =
            new SoundEntry(false, Sound.UI_BUTTON_CLICK, 1.0f, 1.0f, false);

    private final JavaPlugin plugin;
    private final MessageService messages;
    private final Map<UUID, Integer> streaks = new ConcurrentHashMap<>();

    private boolean enabled = true;
    private boolean resetOnDeath = true;
    private boolean resetOnQuit = true;
    private boolean broadcast = true;
    private boolean announceEnd = true;
    private int minEndStreak = 5;
    private final Set<Integer> milestones = new HashSet<>();

    private SoundEntry milestoneSound = DISABLED_SOUND;
    private SoundEntry endedSound = DISABLED_SOUND;
    private final Map<Integer, SoundEntry> milestoneOverrides = new HashMap<>();

    public StreakManager(JavaPlugin plugin, MessageService messages) {
        this.plugin = plugin;
        this.messages = messages;
        loadConfig();
    }

    public void start() {
        if (!enabled) return;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    public void reload() {
        loadConfig();
    }

    public void stop() {
        streaks.clear();
    }

    private void loadConfig() {
        this.enabled = plugin.getConfig().getBoolean("Streak.enabled");
        this.resetOnDeath = plugin.getConfig().getBoolean("Streak.reset-on-death");
        this.resetOnQuit = plugin.getConfig().getBoolean("Streak.reset-on-quit");
        this.broadcast = plugin.getConfig().getBoolean("Streak.broadcast");
        this.announceEnd = plugin.getConfig().getBoolean("Streak.announce-end");
        this.minEndStreak = Math.max(1, plugin.getConfig().getInt("Streak.min-end-streak"));
        this.milestones.clear();
        for (int m : plugin.getConfig().getIntegerList("Streak.milestones")) {
            if (m > 0) milestones.add(m);
        }
        this.milestoneSound = readSound("Streak.sounds.milestone", Sound.ENTITY_ENDER_DRAGON_GROWL);
        this.endedSound = readSound("Streak.sounds.ended", Sound.ENTITY_WITHER_DEATH);
        this.milestoneOverrides.clear();
        ConfigurationSection overrides = plugin.getConfig().getConfigurationSection("Streak.sounds.overrides");
        if (overrides != null) {
            for (String key : overrides.getKeys(false)) {
                try {
                    int milestone = Integer.parseInt(key);
                    SoundEntry entry = readSound("Streak.sounds.overrides." + key, milestoneSound.sound());
                    milestoneOverrides.put(milestone, entry);
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    private SoundEntry readSound(String path, Sound fallback) {
        ConfigurationSection section = plugin.getConfig().getConfigurationSection(path);
        if (section == null) return new SoundEntry(false, fallback, 1.0f, 1.0f, false);
        boolean soundEnabled = section.getBoolean("enabled", true);
        Sound sound = SoundUtils.resolve(section.getString("type"), fallback);
        float volume = (float) section.getDouble("volume", 1.0);
        float pitch = (float) section.getDouble("pitch", 1.0);
        boolean toAll = section.getBoolean("to-all", true);
        return new SoundEntry(soundEnabled, sound, volume, pitch, toAll);
    }

    public int getStreak(UUID id) {
        Integer v = streaks.get(id);
        return v != null ? v : 0;
    }

    public void resetStreak(UUID id) {
        streaks.remove(id);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (!enabled) return;
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        UUID victimId = victim.getUniqueId();

        int previousStreak = getStreak(victimId);

        if (resetOnDeath) {
            streaks.remove(victimId);
        }

        if (killer == null || killer.equals(victim)) return;

        if (announceEnd && previousStreak >= minEndStreak) {
            Component msg = messages.get("Streak.ended",
                    Placeholder.unparsed("killer", killer.getName()),
                    Placeholder.unparsed("victim", victim.getName()),
                    Placeholder.unparsed("streak", String.valueOf(previousStreak)));
            messages.broadcast(msg);
            playSound(endedSound, killer);
        }

        int newStreak = streaks.merge(killer.getUniqueId(), 1, Integer::sum);
        if (milestones.contains(newStreak)) {
            announceMilestone(killer, newStreak);
        }
    }

    private void announceMilestone(Player player, int streak) {
        String specificKey = "Streak.milestones." + streak;
        String key = messages.has(specificKey) ? specificKey : "Streak.milestone";
        Component msg = messages.get(key,
                Placeholder.unparsed("player", player.getName()),
                Placeholder.unparsed("streak", String.valueOf(streak)));
        if (broadcast) {
            messages.broadcast(msg);
        } else {
            player.sendMessage(msg);
        }
        SoundEntry sound = milestoneOverrides.getOrDefault(streak, milestoneSound);
        playSound(sound, player);
    }

    private void playSound(SoundEntry entry, Player source) {
        if (entry == null || !entry.enabled()) return;
        if (entry.toAll()) {
            for (Player online : plugin.getServer().getOnlinePlayers()) {
                online.playSound(online.getLocation(), entry.sound(), entry.volume(), entry.pitch());
            }
        } else if (source != null && source.isOnline()) {
            source.playSound(source.getLocation(), entry.sound(), entry.volume(), entry.pitch());
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (!enabled || !resetOnQuit) return;
        streaks.remove(event.getPlayer().getUniqueId());
    }

    private record SoundEntry(boolean enabled, Sound sound, float volume, float pitch, boolean toAll) {}
}
